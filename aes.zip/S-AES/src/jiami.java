import java.util.Arrays;
import java.util.Scanner;

public class jiami {
    // S盒
    static int[][] s = {
            {9, 4, 10, 11},
            {13, 1, 8, 5},
            {6, 2, 0, 3},
            {12, 14, 15, 7}
    };
    // 替换表
    static int[][] Replace = {
            {0, 0, 0, 0}, {0, 0, 0, 1},
            {0, 0, 1, 0}, {0, 0, 1, 1},
            {0, 1, 0, 0}, {0, 1, 0, 1},
            {0, 1, 1, 0}, {0, 1, 1, 1},
            {1, 0, 0, 0}, {1, 0, 0, 1},
            {1, 0, 1, 0}, {1, 0, 1, 1},
            {1, 1, 0, 0}, {1, 1, 0, 1},
            {1, 1, 1, 0}, {1, 1, 1, 1}
    };

    // 轮常数
    static int[] rcon1 = {1, 0, 0, 0, 0, 0, 0, 0};
    static int[] rcon2 = {0, 0, 1, 1, 0, 0, 0, 0};

    static int[] XR_8(int[] a, int[] b) {
        // a、b 分别是两个长度为 8 的数组，返回一个长度也为 8 的数组
        int[] t = new int[8];  // 结果数组
        for (int i = 0; i < 8; i++) {
            t[i] = a[i] ^ b[i];
        }
        return t;
    }

    // 字节替换
    static void SubBytes(int[] temp) {
        // temp 是一个长度为8的数组，进行S盒替换
        // 先计算出需要进行S盒替换的四位二进制数
        int t1 = 2 * temp[0] + temp[1];
        int t2 = 2 * temp[2] + temp[3];
        int t3 = 2 * temp[4] + temp[5];
        int t4 = 2 * temp[6] + temp[7];
        // 进行 S 盒替换
        int num1 = s[t1][t2];
        int num2 = s[t3][t4];
        // 将替换后的结果按四位四位赋值给temp
        for (int i = 0; i < 4; i++) {
            temp[i] = Replace[num1][i];
        }
        for (int i = 0; i < 4; i++) {
            temp[i + 4] = Replace[num2][i];
        }
    }

    // g函数
    static int[] g(int[] temp, int[] rcon) {
        // temp 是一个长度为8的数组，rcon是轮常数
        int[] t = Arrays.copyOf(temp, temp.length);  // temp是密钥，不能改动，复制一个新的
        // 进行循环左移
        for (int i = 0; i < 4; i++) {
            int tt = t[i + 4];
            t[i + 4] = t[i];
            t[i] = tt;
        }
        // 进行 S 盒替换
        SubBytes(t);
        // 进行轮常数异或
        return XR_8(t, rcon);
    }

    // 轮密钥加
    static void AddRoundKey(int[][] mingwen, int[][] key) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                mingwen[i][j] ^= key[i][j];
            }
        }
    }

    // 行变换
    static void ShiftRows(int[][] temp) {
        // 第一字节的右半部分和第二字节的右半部分进行替换
        for (int i = 4; i < 8; i++) {
            int t = temp[0][i];
            temp[0][i] = temp[1][i];
            temp[1][i] = t;
        }
    }

    // 4位的异或
    static int[] OR_4(int[] a, int[] b) {
        // a、b 分别是两个长度为 4 的数组，返回一个长度也为 4 的数组
        int[] t = new int[4];  // 结果数组
        for (int i = 0; i < 4; i++) {
            t[i] = a[i] ^ b[i];
        }
        return t;
    }

    static void x_fx(int[] f, int[] a) {
        // 进行有限域上的多项式除法运算，用于求解一个元素的逆元
        if (a[0] == 0) {
            for (int i = 0; i < 3; i++) {  // 定义一个长度为4的数组f表示一个3次多项式
                f[i] = a[i + 1];
            }
        } else {
            f[1] = a[2];
            f[2] = a[3] == 1 ? 0 : 1;
            f[3] = 1;
        }
    }

    static int[] multiply(int[] a, int[] b) {
        // 在有限域 GF(2^4) 上的多项式乘法运算
        // 记录下f^n
        int[] f = new int[4];
        x_fx(f, a);
        int[] f2 = new int[4];
        x_fx(f2, f);
        int[] f3 = new int[4];
        x_fx(f3, f2);
        // 现在需要根据多项式a和b开始异或
        int[] result = new int[4];  // 储存结果的系数
        if (b[0] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= f3[i];
            }
        }
        if (b[1] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= f2[i];
            }
        }
        if (b[2] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= f[i];
            }
        }
        if (b[3] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= a[i];
            }
        }
        return result;
    }

    // 列混淆
    static void MixColumns(int[][] mingwen) {
        int[] rule = {0, 1, 0, 0};
        int[] m00 = Arrays.copyOfRange(mingwen[0], 0, 4);
        int[] m10 = Arrays.copyOfRange(mingwen[0], 4, 8);
        int[] m01 = Arrays.copyOfRange(mingwen[1], 0, 4);
        int[] m11 = Arrays.copyOfRange(mingwen[1], 4, 8);

        int[] n00 = OR_4(m00, multiply(rule, m10));  // 乘法结果是1011
        int[] n10 = OR_4(multiply(rule, m00), m10);  // 0101
        int[] n01 = OR_4(m01, multiply(rule, m11));  // 0100
        int[] n11 = OR_4(multiply(rule, m01), m11);  // 0010

        System.arraycopy(n00, 0, mingwen[0], 0, 4);
        System.arraycopy(n10, 0, mingwen[0], 4, 4);
        System.arraycopy(n01, 0, mingwen[1], 0, 4);
        System.arraycopy(n11, 0, mingwen[1], 4, 4);
    }

    public static String encrypt(String mingwen_str, String key_str) {
        int[][] mingwen = new int[2][8];
        int[][] key = new int[2][8];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                mingwen[i][j] = Integer.parseInt(String.valueOf(mingwen_str.charAt(i * 8 + j)));
                key[i][j] = Integer.parseInt(String.valueOf(key_str.charAt(i * 8 + j)));
            }
        }

        // 密钥扩展算法
        int[][] key1 = new int[2][8];
        int[][] key2 = new int[2][8];
        key1[0] = XR_8(key[0], g(key[1], rcon1));
        key1[1] = XR_8(key1[0], key[1]);
        key2[0] = XR_8(key1[0], g(key1[1], rcon2));
        key2[1] = XR_8(key2[0], key1[1]);

        // 第零轮
        AddRoundKey(mingwen, key);

        // 第一轮
        SubBytes(mingwen[0]);
        SubBytes(mingwen[1]);
        ShiftRows(mingwen);
        MixColumns(mingwen);
        AddRoundKey(mingwen, key1);

        // 第二轮
        SubBytes(mingwen[0]);
        SubBytes(mingwen[1]);
        ShiftRows(mingwen);
        AddRoundKey(mingwen, key2);

        // 生成密文字符串
        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                ciphertext.append(mingwen[i][j]);
            }
        }
        return ciphertext.toString();
    }

    public static String asciiToBinary(String input) {
        StringBuilder binaryResult = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            // 获取字符的ASCII值
            int asciiValue = input.charAt(i);
            // 将ASCII值转换为8位二进制字符串
            String binaryString = String.format("%8s", Integer.toBinaryString(asciiValue)).replace(' ', '0');
            binaryResult.append(binaryString);
        }

        return binaryResult.toString();
    }
    public static String binaryToAscii(String binaryInput) {
        StringBuilder asciiResult = new StringBuilder();

        // 二进制字符串按8位分组
        for (int i = 0; i < binaryInput.length(); i += 8) {
            // 取出每8位的二进制字符串
            String binarySegment = binaryInput.substring(i, i + 8);
            // 将二进制字符串转换为对应的十进制整数
            int asciiValue = Integer.parseInt(binarySegment, 2);
            // 将十进制整数转换为对应的ASCII字符并添加到结果中
            asciiResult.append((char) asciiValue);
        }

        return asciiResult.toString();
    }
    public static String encrypt_ascii(String mingwen_str, String key_str)
    {
        String mingwen=asciiToBinary(mingwen_str);
        return binaryToAscii(encrypt(mingwen,key_str));
    }
}

