import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class encryption_model {
    public static void main(String[] args) {
        JFrame frame = new JFrame("简化AES多重加密程序");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 400);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel plaintextLabel = new JLabel("输入：");
        gbc.gridx = 0;
        gbc.gridy = 0;
        frame.add(plaintextLabel, gbc);

        JTextField plaintextField = new JTextField(32);
        gbc.gridx = 1;
        frame.add(plaintextField, gbc);

        JLabel keyLabel = new JLabel("密钥或密文：");
        gbc.gridx = 0;
        gbc.gridy = 1;
        frame.add(keyLabel, gbc);

        JTextField keyField = new JTextField(32);
        gbc.gridx = 1;
        frame.add(keyField, gbc);

        JLabel modeLabel = new JLabel("选择模式：");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; // 跨越两列
        frame.add(modeLabel, gbc);

        String[] modes = {"单次加密算法","ASCII加密","二重加密算法", "三重加密算法","中间相遇攻击","CBC测试"};
        JComboBox<String> modeComboBox = new JComboBox<>(modes);
        gbc.gridx = 1;
        frame.add(modeComboBox, gbc);

        JButton encryptButton = new JButton("加密或测试");
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2; // 跨越两列
        frame.add(encryptButton, gbc);

        JButton decryptButton = new JButton("解密");
        gbc.gridy = 4;
        frame.add(decryptButton, gbc);

        JTextArea resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        frame.add(new JScrollPane(resultArea), gbc);

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plaintext = plaintextField.getText();
                String key = keyField.getText();
                String ciphertext = "";
                String result = "";


                if (modeComboBox.getSelectedItem().equals("二重加密算法")) {
                    ciphertext = double_encryption.double_encrypt(plaintext, key);
                    resultArea.setText("密文为：" + ciphertext);
                } else if (modeComboBox.getSelectedItem().equals("三重加密算法")) {
                    ciphertext = triple_encryption.triple_encrypt(plaintext, key);
                    resultArea.setText("密文为：" + ciphertext);
                }else if (modeComboBox.getSelectedItem().equals("中间相遇攻击")) {
                    result = mid_meet_test.meetInTheMiddle(plaintext, key);
                    resultArea.setText("攻击结果为："+result);
                }else if (modeComboBox.getSelectedItem().equals("单次加密算法")) {
                    ciphertext = jiami.encrypt(plaintext, key);
                    resultArea.setText("密文为：" + ciphertext);
                }else if (modeComboBox.getSelectedItem().equals("CBC测试")) {
                    String[] results = cbc.cbc_test(plaintext, key);
                    resultArea.setText(Arrays.toString(results));
                }else if (modeComboBox.getSelectedItem().equals("ASCII加密")) {
                    ciphertext = jiami.encrypt_ascii(plaintext, key);
                    resultArea.setText("密文为：" + ciphertext);
                }
            }

        });
        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plaintext = plaintextField.getText();
                String key = keyField.getText();


                if (modeComboBox.getSelectedItem().equals("二重加密算法")) {
                    String ciphertext = double_encryption.double_decrypt(plaintext, key);
                    resultArea.setText("明文为：" + ciphertext);
                } else if (modeComboBox.getSelectedItem().equals("三重加密算法")) {
                    String ciphertext= triple_encryption.triple_decrypt(plaintext, key);
                    resultArea.setText("明文为：" + ciphertext);
                }else if (modeComboBox.getSelectedItem().equals("单次加密算法")) {
                    String ciphertext= jiemi.decrypt(plaintext, key);
                    resultArea.setText("明文为：" + ciphertext);
                }else if (modeComboBox.getSelectedItem().equals("ASCII加密")) {
                    String ciphertext = jiemi.decrypt_ascii(plaintext, key);
                    resultArea.setText("明文为：" + ciphertext);
                }
            }
        });
        frame.setVisible(true);
    }
}
