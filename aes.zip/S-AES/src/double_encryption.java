import java.util.Scanner;

public class double_encryption {
    public static String double_encrypt(String mingwen_str, String key_str) {
        // 提取 KEY1, KEY2
        String key_str1 = key_str.substring(0, 16);
        String key_str2 = key_str.substring(16, 32);

        int[][] mingwen = new int[2][8];
        int[][] KEY1 = new int[2][8];
        int[][] KEY2 = new int[2][8];


        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                mingwen[i][j] = Integer.parseInt(String.valueOf(mingwen_str.charAt(i * 8 + j)));
                KEY1[i][j] = Integer.parseInt(String.valueOf(key_str1.charAt(i * 8 + j)));
                KEY2[i][j] = Integer.parseInt(String.valueOf(key_str2.charAt(i * 8 + j)));
            }
        }

        // 双重密钥扩展算法
        //一重
        int[][] key1_1 = new int[2][8];
        int[][] key1_2 = new int[2][8];
        key1_1[0] = jiami.XR_8(KEY1[0], jiami.g(KEY1[1], jiami.rcon1));
        key1_1[1] = jiami.XR_8(key1_1[0], KEY1[1]);
        key1_2[0] = jiami.XR_8(key1_1[0], jiami.g(key1_1[1], jiami.rcon2));
        key1_2[1] = jiami.XR_8(key1_2[0], key1_1[1]);

        // 第零轮
        jiami.AddRoundKey(mingwen, KEY1);

        // 第一轮
        jiami.SubBytes(mingwen[0]);
        jiami.SubBytes(mingwen[1]);
        jiami.ShiftRows(mingwen);
        jiami.MixColumns(mingwen);
        jiami.AddRoundKey(mingwen, key1_1);

        // 第二轮
        jiami.SubBytes(mingwen[0]);
        jiami.SubBytes(mingwen[1]);
        jiami.ShiftRows(mingwen);
        jiami.AddRoundKey(mingwen, key1_2);

        // 生成中间字符串
        int[][] mid_text = new int[2][8];
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                mid_text[i][j]=mingwen[i][j];
            }
        }
        //二重
        int[][] key2_1 = new int[2][8];
        int[][] key2_2 = new int[2][8];
        key2_1[0] = jiami.XR_8(KEY2[0], jiami.g(KEY2[1], jiami.rcon1));
        key2_1[1] = jiami.XR_8(key2_1[0], KEY2[1]);
        key2_2[0] = jiami.XR_8(key2_1[0], jiami.g(key2_1[1], jiami.rcon2));
        key2_2[1] = jiami.XR_8(key2_2[0], key2_1[1]);

        // 第零轮
        jiami.AddRoundKey(mid_text, KEY2);

        // 第一轮
        jiami.SubBytes(mid_text[0]);
        jiami.SubBytes(mid_text[1]);
        jiami.ShiftRows(mid_text);
        jiami.MixColumns(mid_text);
        jiami.AddRoundKey(mid_text, key2_1);

        // 第二轮
        jiami.SubBytes(mid_text[0]);
        jiami.SubBytes(mid_text[1]);
        jiami.ShiftRows(mid_text);
        jiami.AddRoundKey(mid_text, key2_2);

        // 生成密文字符串
        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                ciphertext.append(mid_text[i][j]);
            }
        }
        return ciphertext.toString();
    }
    public static String double_decrypt(String miwen_str, String key_str) {
        // 提取 KEY1, KEY2
        String key_str1 = key_str.substring(0, 16);
        String key_str2 = key_str.substring(16, 32);

        //一重解密
        String mid=jiemi.decrypt(miwen_str,key_str2);
        //二重解密
        String mingwen=jiemi.decrypt(mid,key_str1);

        return mingwen;

    }public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("请输入密文: ");
        String ciphertext_str = scanner.nextLine();

        System.out.print("请输入密钥: ");
        String key_str = scanner.nextLine();

        scanner.close();

        try {
            // 调用解密函数
            String plaintext = double_decrypt(ciphertext_str, key_str);
            System.out.println("明文为：" + plaintext);
        } catch (Exception e) {
            System.out.println("解密过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
