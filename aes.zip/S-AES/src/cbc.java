import java.util.Random;
import java.util.Scanner;

public class cbc {
    // 异或函数
    private static String xor(String str1, String str2) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < str1.length(); i++) {
            result.append(str1.charAt(i) ^ str2.charAt(i));
        }
        return result.toString();
    }

    // 随机生成16位初始向量
    public static String generateIV() {
        Random random = new Random();
        StringBuilder iv = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            iv.append(random.nextInt(2));  // 生成0或1
        }
        return iv.toString();
    }


    public static String[] splitIntoBlocks(String input) {
        int numBlocks = (int) Math.ceil(input.length() / 16.0);
        String[] blocks = new String[numBlocks];

        for (int i = 0; i < numBlocks; i++) {
            int start = i * 16;
            int end = Math.min(start + 16, input.length());
            blocks[i] = input.substring(start, end);
            //如果最后一块不足16位，用0填充
            if (blocks[i].length() < 16) {
                blocks[i] = String.format("%-16s", blocks[i]).replace(' ', '0');
            }
        }

        return blocks;
    }

    // cbc_test函数封装
    public static String[] cbc_test(String input, String key) {
        String[] blocks = splitIntoBlocks(input);
        String iv = generateIV();  // 初始向量
        String previousCipherBlock = iv;  // 初始向量

        // 加密结果
        StringBuilder encryptionResult = new StringBuilder("明文加密结果：\n");
        for (int i = 0; i < blocks.length; i++) {
            String xorResult = xor(blocks[i], previousCipherBlock);
            // 使用加密后的结果更新blocks
            blocks[i] = jiami.encrypt(xorResult, key);
            previousCipherBlock = blocks[i];
            encryptionResult.append(blocks[i]).append("\n");  // 输出每个16位的密文块
        }

        // 正确解密
        StringBuilder decryptionResult = new StringBuilder("正确解密结果：\n");
        String[] true_blocks = blocks;
        previousCipherBlock = iv;  // 初始向量
        for (String true_block : true_blocks) {
            String pre = true_block;
            true_block = jiemi.decrypt(true_block, key);
            true_block = xor(true_block, previousCipherBlock);
            decryptionResult.append(true_block).append("\n");  // 输出每个16位的块
            previousCipherBlock = pre;
        }

        // 对第二个分组进行篡改
        blocks[1] = "1010001001010011";

        StringBuilder tamperedDecryptionResult = new StringBuilder("篡改后解密结果：\n");
        // 错误解密
        String[] false_blocks = blocks;
        previousCipherBlock = iv;  // 初始向量
        for (String false_block : false_blocks) {
            String pre = false_block;
            false_block = jiemi.decrypt(false_block, key);
            false_block = xor(false_block, previousCipherBlock);
            tamperedDecryptionResult.append(false_block).append("\n");  // 输出每个16位的块
            previousCipherBlock = pre;
        }

        // 返回结果
        return new String[] {
                encryptionResult.toString(),
                decryptionResult.toString(),
                tamperedDecryptionResult.toString()
        };
    }
}



