import java.util.HashMap;
import java.util.Map;

public class mid_meet_test {

    // 中间相遇攻击
    public static String meetInTheMiddle(String plaintext, String ciphertext) {
        // 假设密钥的长度是16位二进制字符串
        Map<String, String> forwardMap = new HashMap<>();  // 存储加密半程的结果
        Map<String, String> backwardMap = new HashMap<>();  // 存储解密半程的结果

        // 遍历所有可能的 key_str1
        for (int i = 0; i < (1 << 16); i++) {
            String key_str1 = String.format("%16s", Integer.toBinaryString(i)).replace(' ', '0');  // 确保为16位二进制
            String mid_text1 = jiami.encrypt(plaintext, key_str1);  // 使用 key_str1 加密明文
            forwardMap.put(mid_text1, key_str1);  // 将中间结果存入映射
        }

        // 遍历所有可能的 key_str2
        for (int i = 0; i < (1 << 16); i++) {
            String key_str2 = String.format("%16s", Integer.toBinaryString(i)).replace(' ', '0');  // 确保为16位二进制
            String mid_text2 = jiemi.decrypt(ciphertext, key_str2);  // 使用 key_str2 解密密文
            backwardMap.put(mid_text2, key_str2);  // 将中间结果存入映射

            // 检查是否存在匹配的中间结果
            if (forwardMap.containsKey(mid_text2)) {
                String key_str1 = forwardMap.get(mid_text2);
                System.out.println("找到匹配的密钥对：Key1 = " + key_str1 + ", Key2 = " + key_str2);
                return key_str1 + key_str2;
            }
        }

        // 未找到匹配
        return "未找到密钥";
    }

    public static void main(String[] args) {
        // 假设已经得到了明文、密文对
        String plaintext = "0000011100111000";  // 示例明文
        String ciphertext = "0011000011111011";  // 示例密文

        // 调用中间相遇攻击
        String result = meetInTheMiddle(plaintext, ciphertext);
        System.out.println("攻击结果32位密钥：" + result);
    }
}
