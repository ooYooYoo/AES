import java.util.Arrays;
import java.util.Scanner;

public class jiemi {
    // S盒
    static int[][] sInverse = {
            {10, 5, 9, 11},
            {1, 7, 8, 15},
            {6, 0, 2, 3},
            {12, 4, 13, 14}
    };
    static int[][] s = {
            {9, 4, 10, 11},
            {13, 1, 8, 5},
            {6, 2, 0, 3},
            {12, 14, 15, 7}
    };
    // 替换表
    static int[][] Replace = {
            {0, 0, 0, 0}, {0, 0, 0, 1},
            {0, 0, 1, 0}, {0, 0, 1, 1},
            {0, 1, 0, 0}, {0, 1, 0, 1},
            {0, 1, 1, 0}, {0, 1, 1, 1},
            {1, 0, 0, 0}, {1, 0, 0, 1},
            {1, 0, 1, 0}, {1, 0, 1, 1},
            {1, 1, 0, 0}, {1, 1, 0, 1},
            {1, 1, 1, 0}, {1, 1, 1, 1}
    };

    // 轮常数
    static int[] rcon1 = {1, 0, 0, 0, 0, 0, 0, 0};
    static int[] rcon2 = {0, 0, 1, 1, 0, 0, 0, 0};

    static int[] XR_8(int[] a, int[] b) {
        int[] t = new int[8];
        for (int i = 0; i < 8; i++) {
            t[i] = a[i] ^ b[i];
        }
        return t;
    }
    static int[] OR_4(int[] a, int[] b) {
        // a、b 分别是两个长度为 4 的数组，返回一个长度也为 4 的数组
        int[] t = new int[4];  // 结果数组
        for (int i = 0; i < 4; i++) {
            t[i] = a[i] ^ b[i];
        }
        return t;
    }
    static void SubBytes(int[] temp) {
        // temp 是一个长度为8的数组，进行S盒替换
        // 先计算出需要进行S盒替换的四位二进制数
        int t1 = 2 * temp[0] + temp[1];
        int t2 = 2 * temp[2] + temp[3];
        int t3 = 2 * temp[4] + temp[5];
        int t4 = 2 * temp[6] + temp[7];
        // 进行 S 盒替换
        int num1 = s[t1][t2];
        int num2 = s[t3][t4];
        // 将替换后的结果按四位四位赋值给temp
        for (int i = 0; i < 4; i++) {
            temp[i] = Replace[num1][i];
        }
        for (int i = 0; i < 4; i++) {
            temp[i + 4] = Replace[num2][i];
        }
    }
    static int[] g(int[] temp, int[] rcon) {
        // temp 是一个长度为8的数组，rcon是轮常数
        int[] t = Arrays.copyOf(temp, temp.length);  // temp是密钥，不能改动，复制一个新的
        // 进行循环左移
        for (int i = 0; i < 4; i++) {
            int tt = t[i + 4];
            t[i + 4] = t[i];
            t[i] = tt;
        }
        // 进行 S 盒替换
        SubBytes(t);
        // 进行轮常数异或
        return XR_8(t, rcon);
    }
    // 字节替换逆
    static void SubBytesInverse(int[] temp) {
        int t1 = 2 * temp[0] + temp[1];
        int t2 = 2 * temp[2] + temp[3];
        int t3 = 2 * temp[4] + temp[5];
        int t4 = 2 * temp[6] + temp[7];
        // 进行 S 盒替换
        int num1 = sInverse[t1][t2];
        int num2 = sInverse[t3][t4];
        // 将替换后的结果按四位四位赋值给temp
        for (int i = 0; i < 4; i++) {
            temp[i] = Replace[num1][i];
        }
        for (int i = 0; i < 4; i++) {
            temp[i + 4] = Replace[num2][i];
        }
    }


    // 轮密钥加
    static void AddRoundKey(int[][] miwen, int[][] key) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                miwen[i][j] ^= key[i][j];
            }
        }
    }

    // 行变换逆
    static void ShiftRowsInverse(int[][] temp) {
        for (int i = 4; i < 8; i++) {
            int t = temp[0][i];
            temp[0][i] = temp[1][i];
            temp[1][i] = t;
        }
    }
    static void x_fx(int[] f, int[] a) {
        // 进行有限域上的多项式除法运算，用于求解一个元素的逆元
        if (a[0] == 0) {
            for (int i = 0; i < 3; i++) {  // 定义一个长度为4的数组f表示一个3次多项式
                f[i] = a[i + 1];
            }
        } else {
            f[1] = a[2];
            f[2] = a[3] == 1 ? 0 : 1;
            f[3] = 1;
        }
    }
    static int[] multiply(int[] a, int[] b) {
        // 在有限域 GF(2^4) 上的多项式乘法运算
        // 记录下f^n
        int[] f = new int[4];
        x_fx(f, a);
        int[] f2 = new int[4];
        x_fx(f2, f);
        int[] f3 = new int[4];
        x_fx(f3, f2);
        // 现在需要根据多项式a和b开始异或
        int[] result = new int[4];  // 储存结果的系数
        if (b[0] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= f3[i];
            }
        }
        if (b[1] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= f2[i];
            }
        }
        if (b[2] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= f[i];
            }
        }
        if (b[3] == 1) {
            for (int i = 0; i < 4; i++) {
                result[i] ^= a[i];
            }
        }
        return result;
    }
    // 列混淆逆
    static void MixColumnsInverse(int[][] miwen) {
        int[] rule1 = {1, 0, 0, 1};
        int[] rule2 = {0, 0, 1, 0};

        int[] m00 = Arrays.copyOfRange(miwen[0], 0, 4);
        int[] m10 = Arrays.copyOfRange(miwen[0], 4, 8);
        int[] m01 = Arrays.copyOfRange(miwen[1], 0, 4);
        int[] m11 = Arrays.copyOfRange(miwen[1], 4, 8);

        int[] n00 = OR_4(multiply(rule1, m00), multiply(rule2, m10));
        int[] n10 = OR_4(multiply(rule2, m00), multiply(rule1,m10));
        int[] n01 = OR_4(multiply(rule1, m01), multiply(rule2, m11));
        int[] n11 = OR_4(multiply(rule2, m01), multiply(rule1,m11));

        System.arraycopy(n00, 0, miwen[0], 0, 4);
        System.arraycopy(n10, 0, miwen[0], 4, 4);
        System.arraycopy(n01, 0, miwen[1], 0, 4);
        System.arraycopy(n11, 0, miwen[1], 4, 4);
    }

    public static String decrypt(String ciphertext_str, String key_str) {
        int[][] miwen = new int[2][8];
        int[][] key = new int[2][8];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                miwen[i][j] = Integer.parseInt(String.valueOf(ciphertext_str.charAt(i * 8 + j)));
                key[i][j] = Integer.parseInt(String.valueOf(key_str.charAt(i * 8 + j)));
            }
        }

        // 密钥扩展算法
        int[][] key1 = new int[2][8];
        int[][] key2 = new int[2][8];
        key1[0] = XR_8(key[0], g(key[1], rcon1));
        key1[1] = XR_8(key1[0], key[1]);
        key2[0] = XR_8(key1[0], g(key1[1], rcon2));
        key2[1] = XR_8(key2[0], key1[1]);

        // 反向解密过程
        //第零轮
        AddRoundKey(miwen, key2);
        //第一轮
        ShiftRowsInverse(miwen);
        SubBytesInverse(miwen[1]);
        SubBytesInverse(miwen[0]);
        AddRoundKey(miwen, key1);
        MixColumnsInverse(miwen);

        // 第二轮
        ShiftRowsInverse(miwen);
        SubBytesInverse(miwen[1]);
        SubBytesInverse(miwen[0]);
        AddRoundKey(miwen, key);

        // 生成明文字符串
        StringBuilder plaintext = new StringBuilder();
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                plaintext.append(miwen[i][j]);
            }
        }
        return plaintext.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("请输入密文: ");
        String ciphertext_str = scanner.nextLine();

        System.out.print("请输入密钥: ");
        String key_str = scanner.nextLine();

        scanner.close();

        try {
            // 调用解密函数
            String plaintext = decrypt(ciphertext_str, key_str);
            System.out.println("明文为：" + plaintext);
        } catch (Exception e) {
            System.out.println("解密过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
