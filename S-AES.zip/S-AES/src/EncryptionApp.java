import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EncryptionApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("简化AES加密解密程序");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel plaintextLabel = new JLabel("输入：");
        gbc.gridx = 0;
        gbc.gridy = 0;
        frame.add(plaintextLabel, gbc);

        JTextField plaintextField = new JTextField(16);
        gbc.gridx = 1;
        frame.add(plaintextField, gbc);

        JLabel keyLabel = new JLabel("密钥：");
        gbc.gridx = 0;
        gbc.gridy = 1;
        frame.add(keyLabel, gbc);

        JTextField keyField = new JTextField(16);
        gbc.gridx = 1;
        frame.add(keyField, gbc);

        JButton encryptButton = new JButton("加密");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; // 跨越两列
        frame.add(encryptButton, gbc);

        JButton decryptButton = new JButton("解密");
        gbc.gridy = 3;
        frame.add(decryptButton, gbc);

        JTextArea resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        frame.add(new JScrollPane(resultArea), gbc);

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plaintext = plaintextField.getText();
                String key = keyField.getText();
                String ciphertext = jiami.encrypt(plaintext, key);
                resultArea.setText("密文为：" + ciphertext);
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ciphertext = plaintextField.getText();
                String key = keyField.getText();
                String plaintext = jiemi.decrypt(ciphertext, key);
                resultArea.setText("明文为：" + plaintext);
            }
        });

        frame.setVisible(true);
    }
}
